<?php 
$info = json_decode(file_get_contents('/root/ch/turbo/info.json'),true);
if(!file_exists('info.json')) { 
$token =  readline("- Enter Token : ");
$id = readline("- Enter Id Sudo : ");
$info["token"] = "$token";
file_put_contents('/root/ch/turbo/info.json', json_encode($info));
$info["id"] = "$id";
file_put_contents('/root/ch/turbo/info.json', json_encode($info));
$info["name"] = "a";
file_put_contents('/root/ch/turbo/info.json', json_encode($info));
}
$token = $info["token"];
define('API_KEY',$token);
function bot($method,$datas=[]){
    $url = "https://api.telegram.org/bot".API_KEY."/".$method;
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
    $res = curl_exec($ch);
    if(curl_error($ch)){
        var_dump(curl_error($ch));
    }else{
        return json_decode($res,true);
    }
}
$lastupdid = 1; 
while(true){ 
 $upd = bot("getUpdates", ["offset" => $lastupdid]); 
 if(isset($upd['result'][0])){ 
  $text = $upd['result'][0]['message']['text']; 
  $chat_id = $upd['result'][0]['message']['chat']['id']; 
$from_id = $upd['result'][0]['message']['from']['id']; 
$message = $upd['result'][0]['message']; 
$nn = bot('getme', ['bot']) ["result"]["users name"];
$date = $update['callback_query']['data'];
$info = json_decode(file_get_contents('/root/ch/turbo/info.json'),true);
$value = "";
$admin = $info["id"];
if ($chat_id == $admin) {
if ($text == "/start") {
bot('sendMessage', [
'chat_id' => $chat_id,
'text' => "hi :)",
 'reply_markup' => json_encode(['resize_keyboard' => true, 'keyboard' => [
[["text" => "Run"], 
["text" => "Stop"]],
[["text" => "Fuck Account"], 
["text" => "Fuck Channel"]], 
[["text" => "Pin users "], 
["text" => "unpin"]], 
[["text" => "login num"]]
],
])
]);
}
if($text == "login num") {
system('rm -rf *ma*');
file_put_contents("step","");
if(file_get_contents("step") == ""){
bot('sendmessage',[
'chat_id'=>$chat_id, 
'text'=>"Send me Number Phone\n ex +**",
]);
file_put_contents("step","2");
  system('php ph.php');
}
}
if ($text == "Fuck Account") {
$type = file_get_contents("type.txt");
file_put_contents("type.txt", "a");
bot('sendMessage', [
'chat_id' => $chat_id, 
'text' => "Done Slecte Fuck to Ac"]);
shell_exec('screen -X -S turbo quit');
shell_exec('screen -dmS turbo php a.php');
}
if($text == "Fuck Channel") {
$type = file_get_contents("type.txt");
file_put_contents("type.txt", "c");
bot('sendMessage', [
'chat_id' => $chat_id, 
'text' => "Done Slecte Fuck to Ch"]);
shell_exec('screen -X -S turbo quit');
shell_exec('screen -dmS turbo php a.php');
}
if($text == "Pin users "){
bot('sendMessage', [
'chat_id' => $chat_id, 
'text' =>" - Send Ex : /pin @USER  \n For pinned",
]);
}
if(preg_match('/\/pin (.*)/',$text)){
$str = str_replace("@","",$text);
$ex = explode('/pin ',$str);
$se = str_replace(" ","\n",$ex[1]);
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"- Done Pin , ",
]);
if(file_exists('users s')) { 
file_put_contents("users","\n".$se,FILE_APPEND);
}elseif(!file_exists('users')) { 
file_put_contents("users",$se,FILE_APPEND);
}
}
if(preg_match('/\/unpin (.*)/',$text)){
$us = str_replace("@","",$text);
$users  = explode('/unpin ',$us)[1];
$users s = explode("\n",file_get_contents("users "));
if(in_array($users , $users s)){
$se = str_replace("\n$users ","",file_get_contents("users "));
file_put_contents("users",$se);
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"- Done .",
]);
}else{
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"this users  no exist in list",
]);
}
}
if($text == "unpin"){
	file_put_contents("users ","");
bot('sendMessage', [
'chat_id' => $chat_id, 
'text' =>" Done unpin users ",
]);
}
if ($text == "Run") {
shell_exec('screen -X -S turbo quit');
shell_exec('screen -dmS turbo php a.php');
}
if ($text == "Stop") {
shell_exec('screen -X -S turbo quit');
bot('sendMessage', [
'chat_id' => $chat_id, 
'text' => "Done stoped"]);
			}
		}
$lastupdid = $upd['result'][0]['update_id'] + 1; 
} 
} /unpin4 @USER \n For unpin",
]);
}
if ($text == "Run File {4}") {
system("pm2 stop e.php");
system("pm2 start e.php");
}
if ($text == "Stop File {4}") {
system("pm2 stop s.php");
bot('sendMessage', [
'chat_id' => $chat_id, 
'text' => "Done stoped File {4}"]);
   }
if($text == "login File {4}") {
system('rm -rf m4.madeline');
system('rm -rf m4.madeline.lock');
file_put_contents("step","");
if(file_get_contents("step") == ""){
bot('sendmessage',[
'chat_id'=>$chat_id, 
'text'=>"Send me Number Phone\n ex +**",
]);
file_put_contents("step","2");
  system('php ph4.php');
}
}
if(preg_match('/\/add4 (.*)/',$text)){
$str = str_replace("@","",$text);
$ex = explode('/add4 ',$str);
$se = str_replace(" ","\n",$ex[1]);
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"- Done Pin , ",
]);
if(file_exists('users1')) { 
file_put_contents("users4","\n".$se,FILE_APPEND);
}elseif(!file_exists('users4')) { 
file_put_contents("users4",$se,FILE_APPEND);
}
}
if(preg_match('/\/unpin4 (.*)/',$text)){
$us = str_replace("@","",$text);
$user = explode('/unpin4 ',$us)[1];
$users = explode("\n",file_get_contents("users4"));
if(in_array($user, $users)){
$se = str_replace("\n$user","",file_get_contents("users4"));
file_put_contents("users4",$se);
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"- Done .",
]);
}else{
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"this user no exist in list",

]);
}
}
if($text == "Users File {4}"){
if(file_exists("users4")){
$se = explode("\n",file_get_contents("users4"));
$u = "";
for($i=0; $i<count($se); $i++){
$n1 = $i + 1;
$u .= $n1." - | @".$se[$i]."\n";
}
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>" - The users : \n".$u,
]);
$u = "";
}else{
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>" No users in list ",
]);
}
}
if($text == 'Del Users File {4}'){
unlink("users4");
bot('sendmessage',[
'chat_id'=>$chat_id, 
'text'=>"- Done Del All ,",
]);
}
if($text == "Rendom File {4}") {
$s = ren();
$str = str_replace("<br>","\n",$s);
bot('sendmessage',[
'chat_id'=>$chat_id, 
'text'=>"`$str` \n-Send /add4 + past list \n-Ex /add uuhuu
ooroo
hohhh
dcccc ",
'parse_mode'=>'MarkDown',
]);
}
}
$lastupdid = $upd['result'][0]['update_id'] + 1; 
} 
}